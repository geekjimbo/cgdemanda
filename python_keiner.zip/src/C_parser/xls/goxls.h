extern char * lines;
int readSheet(char * filename, char * sheetName);